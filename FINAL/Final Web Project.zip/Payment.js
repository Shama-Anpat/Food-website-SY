function validate(){
  var name = document.getElementById("name").value;
  var number = document.getElementById("number").value;
  var expdate = document.getElementById("expdate").value;
  var cvv = document.getElementById("cvv").value;
  var address = document.getElementById("address").value;
  var error_message = document.getElementById("error_message");
  
  error_message.style.padding = "10px";
  
  var text;

  if(name.length < 5){
    text = "Please Enter valid Name";
    error_message.innerHTML = text;
    return false;
  }
  if(number.length < 16){
    text = "Please Enter valid Number";
    error_message.innerHTML = text;
    return false;
  }

  if(cvv.length < 3){
    text = "Please Enter valid CVV ";
    error_message.innerHTML = text;
    return false;
  }
  
  if(address.length <= 15){
    text = "Please Enter atlest 40 characters";
    error_message.innerHTML = text;
    return false;
  }
  
  alert("Payment done Successfully!");
  return true;
}