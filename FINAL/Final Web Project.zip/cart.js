var idList = []
var quantityList = []
var totalPriceList = [null]

function Fetch() {
    //Data from local storage
    var productIDs = localStorage.getItem('ProductID')
    var productQuantities = localStorage.getItem('ProductQuantity')
    
    //Convert to array
    idList = productIDs.split(",")
    quantityList = productQuantities.split(",")
}

function RemoveItem(id) {
    // console.log("YOu just removed the index" + id)
    // remove the data[id] from the lists
    idList.splice(id, 1)
    quantityList.splice(id, 1)
    //Convert the list to string
    idList.toString()
    quantityList.toString()
    // append the new list to the local storage
    localStorage.setItem("ProductID", idList)
    localStorage.setItem("ProductQuantity", quantityList)
    location.reload();
}

function loadXMLDoc() {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function(){
        if (this.readyState == 4 && this.status == 200) {
            Fetch();
            itemsLoad(this);
            TotalBill()
        }
    };
    xmlhttp.open("GET", "Menu_Page.xml", true);
    xmlhttp.send();
}

function itemsLoad(xml){
    var x, xmlDoc, items, totalPrice;
    var button = '<i onclick="RemoveItem()" class="fa fa-trash" aria-hidden="true"></i>'

    xmlDoc = xml.responseXML;
    x = xmlDoc.getElementsByTagName("food")

    //calculating the total price
    for (var j = 1; j < quantityList.length ; j++) {
        totalPrice = parseInt(quantityList[j]) * parseInt(x[idList[j]].getElementsByTagName("rate")[0].childNodes[0].nodeValue)
        totalPriceList.push(totalPrice)
        // console.log(totalPriceList)
    }

    //Adding the data in items[]
    items = "<tr><td>" + x[idList[1]].getElementsByTagName("name")[0].childNodes[0].nodeValue + "</td><td>" + quantityList[1] + "</td><td>" + totalPriceList[1] + "</td><td>" + '<i onclick="RemoveItem(' + 1 + ')" class="fa fa-trash" aria-hidden="true"></i>' + "</td></tr>";
    for (var i = 2; i < idList.length; i++) {
        var id = idList[i]
        items += "<tr><td>" + x[id].getElementsByTagName("name")[0].childNodes[0].nodeValue + "</td><td>" + quantityList[i] + "</td><td>" + totalPriceList[i] + "</td><td>" + '<i onclick="RemoveItem(' + i + ')" class="fa fa-trash" aria-hidden="true"></i>' + "</td></tr>" ;
    }
    //Appending into the document
    document.getElementById("items").innerHTML = items;
}

function TotalBill() {
    var bill = 0
    for (let i = 1; i < totalPriceList.length; i++) {
        bill += totalPriceList[i]
        document.getElementById("bill").innerHTML = bill
        console.log(bill)
        
    }
}