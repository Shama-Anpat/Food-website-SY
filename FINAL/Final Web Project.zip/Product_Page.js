//#region Counter
var numbers = document.getElementById('box');
var span = document.createElement('span');
    span.id = 'productQuantity';
    span.textContent = 1;
    numbers.appendChild(span);
    
for(i=2;i<10;i++)
{
    var span = document.createElement('span');
    span.textContent = i;
    numbers.appendChild(span);
}
var num = numbers.getElementsByTagName('span');
var index = 0;

function nextNum(){
    num[index].style.display = 'none';
    num[index].id = "null";
    index = (index + 1) % num.length;
    num[index].style.display = 'initial';
    num[index].id = "productQuantity";
}

function prevNum(){
    num[index].style.display = 'none';
    num[index].id = "null";
    index = (index -  1 + num.length ) % num.length;
    num[index].style.display = 'initial';
    num[index].id = "productQuantity";
}
//#endregion

//#region LoadData

var idnum = 1;  //Global Variable you can give any value

function loadID() {
    idnum = localStorage.getItem("Id")
}

function loadXMLDoc() {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function(){
        if (this.readyState == 4 && this.status == 200) {
        loadID();
        imgLoad();
        ingreLoad(this);
        nameLoad(this);
        despLoad(this);
        }
    };
    xmlhttp.open("GET", "Menu_Page.xml", true);
    xmlhttp.send();
    console.log(idnum);
}

function ingreLoad(xml){
    var x, xmlDoc, list;
    xmlDoc = xml.responseXML;
    x = xmlDoc.getElementsByTagName("food")
    list = "<li><h4><span>• " + x[idnum].getElementsByTagName("ing")[0].childNodes[0].nodeValue + "</span></h4></li>";
    for (var i = 1; i < x[idnum].getElementsByTagName("ing").length; i++){
        list += "<li><h4><span>• " + x[idnum].getElementsByTagName("ing")[i].childNodes[0].nodeValue + "</span></h4></li>";
    }
    document.getElementById("ing").innerHTML = list;
}

function nameLoad(xml){
    var x, xmlDoc, name;
    xmlDoc = xml.responseXML;
    x = xmlDoc.getElementsByTagName("food")
    name = "<h1><span>" + x[idnum].getElementsByTagName("name")[0].childNodes[0].nodeValue + "</h1></span>";
    document.getElementById("name").innerHTML = name;
}

function imgLoad() {
    var img = document.getElementById("image-container");
        img.setAttribute("src", "IMGS/" + idnum + ".jpg");

        document.getElementsByClassName("top-section").innerHTML = img;
        console.log(img);
}
function despLoad(xml){
    var x, xmlDoc, desp;
    xmlDoc = xml.responseXML;
    x = xmlDoc.getElementsByTagName("food")
    desp = "<h4><span> " + x[idnum].getElementsByTagName("desp")[0].childNodes[0].nodeValue + "</span></h4>";
    document.getElementById("desp").innerHTML = desp;
}
//#endregion

//#region Cart
function AddToCart() {
    var dataList = []
    var quantityList =  []
    //Fetch ID
    var productID = localStorage.getItem("Id")
    //Fetch Quantity
    var productQuantity = document.getElementById('productQuantity').textContent

    //get local storage
    var productIDLocal = localStorage.getItem('ProductID')
    var productQuantityLocal = localStorage.getItem('ProductQuantity')

    //Create id key in local storage if it does not exist
    if (productIDLocal == null) {
        localStorage.setItem('ProductID', null)
        productIDLocal = localStorage.getItem('ProductID')
    }
    dataList = productIDLocal.split(",")
    
    //Create quantity key in local storage if it does not exist
    if (productQuantityLocal == null) {
        localStorage.setItem('ProductQuantity', null)
        productQuantityLocal = localStorage.getItem('ProductQuantity')
    }
    quantityList = productQuantityLocal.split(",")
    quantityList = quantityList.map((i) => Number(i))

    //Add the data to their lists
    //take the index of id from its list and add quantity to its list with the same index
    if (dataList.includes(productID)) {
        var index = dataList.indexOf(productID)
        console.log("Product Id already exists at" + dataList.indexOf(productID))
        //Add only Quantity to the respective index
        // quantityList.splice(index, 0, productQuantity)
        quantityList[index] += parseInt(productQuantity)
        quantityList.toString()
        localStorage.setItem('ProductQuantity', quantityList)
    } 
    else {
        //Add id
        dataList.push(productID)
        dataList.toString()
        localStorage.setItem('ProductID', dataList)
        //Add quantity
        var index = dataList.indexOf(productID)
        // quantityList.splice(index, 0, productQuantity)
        quantityList[index] = productQuantity
        quantityList.toString()
        localStorage.setItem('ProductQuantity', quantityList)
    }
    console.log(dataList)
    console.log(quantityList)
}


//#endregion